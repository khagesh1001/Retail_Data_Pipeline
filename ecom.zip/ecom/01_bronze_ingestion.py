# Databricks notebook source
# MAGIC %md
# MAGIC # Bronze Layer - Incremental Ingestion
# MAGIC
# MAGIC This notebook loads raw CSV data from Databricks Volume 
# MAGIC and performs incremental ingestion into Bronze Delta table.

# COMMAND ----------

# DBTITLE 1,Bronze Ingestion
from pyspark.sql import SparkSession

# Batch ingestion (CSV)
df = spark.read.format("csv") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .load("/Volumes/ecommerce_cat/ecom/e-com_source/online_retail_II.csv")

df = df.withColumnRenamed("Customer ID", "customer_id") \
       .withColumnRenamed("Invoice", "invoice") \
       .withColumnRenamed("InvoiceDate", "invoicedate") \
       .withColumnRenamed("StockCode", "stockcode") \
       .withColumnRenamed("Description", "description") \
       .withColumnRenamed("Quantity", "quantity") \
       .withColumnRenamed("UnitPrice", "price") \
       .withColumnRenamed("Country", "country")

df.write.format("delta") \
    .mode("append") \
    .saveAsTable("ecommerce_cat.ecom.bronze_transactions")


# # Optional: Streaming ingestion
# stream_df = spark.readStream.format("cloudFiles") \
#     .option("cloudFiles.format", "csv") \
#     .option("header", "true") \
#     .load("/Volumes/ecommerce_cat/ecom/e-com_source/online_retail_II.csv")

# stream_df.writeStream.format("delta") \
#     .option("checkpointLocation", "/delta/checkpoints/bronze_transactions") \
#     .outputMode("append") \
#     .table("ecommerce_cat.ecom.bronze_transactions")
