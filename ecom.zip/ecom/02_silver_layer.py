# Databricks notebook source
# MAGIC %md
# MAGIC ##  Silver Layer
# MAGIC This notebook cleans the data from bronze layer

# COMMAND ----------

df_silver = spark.sql("""
SELECT DISTINCT
    REGEXP_REPLACE(TRIM(customer_id), '[^0-9]', '') AS customer_id,
    UPPER(REGEXP_REPLACE(TRIM(StockCode), '[^0-9]', '')) AS StockCode,
    UPPER(TRIM(Description)) AS Description,
    REGEXP_REPLACE(TRIM(Invoice), '[^0-9]', '') AS Invoice,
    quantity,
    price,
    invoicedate,
    country,
    (quantity * price) AS order_value,
    YEAR(invoicedate) AS year,
    MONTH(invoicedate) AS month
FROM ecommerce_cat.ecom.bronze_transactions
WHERE customer_id IS NOT NULL AND TRIM(customer_id) <> ''
  AND StockCode IS NOT NULL AND TRIM(StockCode) <> ''
  AND Description IS NOT NULL AND TRIM(Description) <> ''
  AND quantity > 0
  AND price > 0
""")

df_silver.write.format("delta") \
    .mode("overwrite") \
      .option("overwriteSchema", "true") \
    .saveAsTable("ecommerce_cat.ecom.silver_transactions")
