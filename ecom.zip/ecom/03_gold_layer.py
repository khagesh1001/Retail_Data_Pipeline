# Databricks notebook source
# DBTITLE 1,Customer Metrics
# Customer revenue
df_gold_customer = spark.sql("""
SELECT
    customer_id,
    ROUND(SUM(order_value), 2) AS total_spent,
    COUNT(DISTINCT Invoice) AS total_orders
FROM ecommerce_cat.ecom.silver_transactions
GROUP BY customer_id
""")
df_gold_customer.write.format("delta") \
    .mode("overwrite") \
    .saveAsTable("ecommerce_cat.ecom.gold_customer_metrics")

# Monthly revenue
df_gold_sales = spark.sql("""
SELECT
    year,
    month,
    ROUND(SUM(order_value), 2) AS monthly_revenue
FROM ecommerce_cat.ecom.silver_transactions
GROUP BY year, month
ORDER BY year, month
""")
df_gold_sales.write.format("delta") \
    .mode("overwrite") \
    .saveAsTable("ecommerce_cat.ecom.gold_sales_metrics")

# Top products
df_gold_products = spark.sql("""
SELECT
    StockCode,
    Description,
    SUM(quantity) AS total_quantity,
    ROUND(SUM(order_value), 2) AS revenue
FROM ecommerce_cat.ecom.silver_transactions
GROUP BY StockCode, Description
""")
df_gold_products.write.format("delta") \
    .mode("overwrite") \
    .saveAsTable("ecommerce_cat.ecom.gold_product_metrics")
