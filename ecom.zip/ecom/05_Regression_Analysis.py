# Databricks notebook source
# DBTITLE 1,Importing Libraries
from pyspark.sql.functions import col, year, month
from pyspark.ml.feature import VectorAssembler, StringIndexer, OneHotEncoder
from pyspark.ml.regression import LinearRegression, GBTRegressor, RandomForestRegressor
from pyspark.ml import Pipeline

# COMMAND ----------

# DBTITLE 1,Load Silver
df = spark.table("ecommerce_cat.ecom.silver_transactions")
df = df.limit(4000)

# COMMAND ----------

df = df.filter(
    (col("stockcode").isNotNull()) & (col("stockcode") != "") &
    (col("country").isNotNull()) & (col("country") != "") &
    (col("quantity") > 0) &
    (col("price") > 0)
)

# COMMAND ----------

# DBTITLE 1,Predict Order Value
# Feature engineering
indexer_stock = StringIndexer(inputCol="stockcode", outputCol="stockcode_index")
encoder_stock = OneHotEncoder(inputCol="stockcode_index", outputCol="stockcode_vec")

indexer_country = StringIndexer(inputCol="country", outputCol="country_index")
encoder_country = OneHotEncoder(inputCol="country_index", outputCol="country_vec")

# Assemble features: quantity, price, stockcode, country
assembler = VectorAssembler(
    inputCols=["quantity", "price", "stockcode_vec", "country_vec"],
    outputCol="features"
)

# Model: Gradient Boosted Tree Regression
gbt_order = GBTRegressor(featuresCol="features", labelCol="order_value")

pipeline_order = Pipeline(stages=[indexer_stock, encoder_stock,
                                  indexer_country, encoder_country,
                                  assembler, gbt_order])

# Fit model
model_order = pipeline_order.fit(df)
pred_order = model_order.transform(df)

pred_order.select("order_value", "prediction").show(5)

# COMMAND ----------

# DBTITLE 1,Predict Quantity Purchased
# Reuse same features but label = quantity
gbt_quantity = GBTRegressor(featuresCol="features", labelCol="quantity")

pipeline_quantity = Pipeline(stages=[indexer_stock, encoder_stock,
                                     indexer_country, encoder_country,
                                     assembler, gbt_quantity])

model_quantity = pipeline_quantity.fit(df)
pred_quantity = model_quantity.transform(df)

pred_quantity.select("quantity", "prediction").show(5)

# COMMAND ----------

# DBTITLE 1,Predict Monthly Revenue
# Aggregate monthly revenue per country
df_monthly = df.withColumn("year", year("invoicedate")) \
               .withColumn("month", month("invoicedate")) \
               .groupBy("year", "month") \
               .sum("order_value") \
               .withColumnRenamed("sum(order_value)", "monthly_revenue")

# Feature: year, month (numeric)
assembler_monthly = VectorAssembler(
    inputCols=["year", "month"],
    outputCol="features"
)

lr_monthly = LinearRegression(featuresCol="features", labelCol="monthly_revenue")

pipeline_monthly = Pipeline(stages=[assembler_monthly, lr_monthly])

model_monthly = pipeline_monthly.fit(df_monthly)
pred_monthly = model_monthly.transform(df_monthly)

pred_monthly.select("year", "month", "monthly_revenue", "prediction").show(5)