# Databricks notebook source
# MAGIC %md
# MAGIC # Analytics & Insights 
# MAGIC This notebook refers the silver layer to do a cohort analysis as per user cohort.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Top 10 customers
# MAGIC SELECT *
# MAGIC FROM ecommerce_cat.ecom.gold_customer_metrics
# MAGIC ORDER BY total_spent DESC
# MAGIC LIMIT 10;
# MAGIC
# MAGIC -- Monthly revenue trends
# MAGIC SELECT year, month, monthly_revenue
# MAGIC FROM ecommerce_cat.ecom.gold_sales_metrics
# MAGIC ORDER BY year, month;
# MAGIC
# MAGIC -- Top selling products
# MAGIC SELECT *
# MAGIC FROM ecommerce_cat.ecom.gold_product_metrics
# MAGIC ORDER BY revenue DESC
# MAGIC LIMIT 10;
# MAGIC

# COMMAND ----------


